```markdown
<p align="center">
  <img src="../sopotek-trading-ai/src/assets/logo.png" width="300">
</p>

<h1 align="center">Sopotek Trading AI</h1>

<p align="center">
Institutional-grade event-driven algorithmic trading platform  
for crypto, forex, and stock markets.
</p>

---


## Overview

![image](../sopotek-trading-ai/src/assets/logo_170X170.png)

Sopotek Trading AI is a modular, event-driven algorithmic trading platform designed for **multi-asset trading** across cryptocurrency, forex, and stock markets.

The system supports:

- live trading
- backtesting
- machine learning strategies
- institutional-grade risk management
- a real-time trading GUI

---

# Features

### Multi-Asset Trading

- **Crypto**
  - Binance
  - Coinbase
  - Kraken
  - KuCoin
  - Bybit

- **Forex**
  - OANDA

- **Stocks**
  - Alpaca

---

### Event-Driven Architecture

The platform uses an **event bus architecture** for high scalability and asynchronous processing.

This allows components to operate independently while communicating through events.

---

### Algorithmic Trading Strategies

Built-in strategies include:

- Momentum
- Mean Reversion
- Arbitrage

Strategies can be extended easily through the **strategy module**.

---

### Machine Learning Models

Supported ML frameworks:

- Scikit-Learn
- XGBoost
- Hidden Markov Models (HMM)

ML models can generate trading signals and adapt to market regimes.

---

### Institutional Risk Management

Risk engine includes:

- Portfolio exposure limits
- Position sizing
- Drawdown protection
- Risk-per-trade control

---

### Backtesting Engine

The platform includes a full historical simulation engine allowing:

- strategy testing
- performance analysis
- risk evaluation

---

### Real-Time Market Data

Streaming market data using:

- WebSockets
- asynchronous pipelines

---

### GUI Trading Terminal

Modern desktop interface built with:

- **PySide6**
- **PyQtGraph**

Features include:

- charts
- portfolio monitoring
- order book
- strategy control

---

# Project Structure

```

sopotek-trading-ai
│
├── config
├── scripts
├── data
├── models
├── logs
├── docs
├── tests
│
└── src
└── sopotek_trading
├── broker
├── engines
├── event_bus
├── strategy
├── risk
├── portfolio
├── execution
├── quant
├── backtesting
├── frontend
└── utils

````

---

# Installation

## 1 Clone the Repository

```bash
git clone https://github.com/sopotek/sopotek-trading-ai.git
cd sopotek-trading-ai
````

---

## 2 Create Virtual Environment

```bash
python -m venv .venv
```

Activate environment

### Windows

```bash
.venv\Scripts\activate
```

### Linux / Mac

```bash
source .venv/bin/activate
```

---

## 3 Install Dependencies

```bash
pip install -r requirements.txt
```

---

# Configuration

Create a `.env` file and add your API credentials.

Example:

```
BINANCE_API_KEY=your_key
BINANCE_SECRET=your_secret

ALPACA_API_KEY=your_key
ALPACA_SECRET=your_secret

OANDA_TOKEN=your_token
OANDA_ACCOUNT=your_account
```

---

# Running the System

### Run Live Trading

```
python scripts/run_live.py
```

### Run Backtesting

```
python scripts/run_backtest.py
```

### Train Machine Learning Models

```
python scripts/train_models.py
```

### Download Market Data

```
python scripts/download_data.py
```

---

# Data Pipeline

```
Exchange Data
     ↓
data/raw
     ↓
data/processed
     ↓
data/features
     ↓
ML Models / Strategies
```

---

# Event-Driven Architecture

The trading system uses an **event bus** to coordinate components.

```
Market Data
     ↓
Event Bus
     ↓
Strategy Engine
     ↓
Risk Engine
     ↓
Execution Engine
     ↓
Portfolio Manager
```

This design enables:

* high scalability
* asynchronous processing
* modular strategy development

---

# Testing

Run all tests with:

```bash
pytest tests/
```

---

# Supported Markets

| Market | Broker |
| ------ | ------ |
| Crypto | CCXT   |
| Forex  | OANDA  |
| Stocks | Alpaca |

---

# Technology Stack

### Core

* Python
* NumPy
* Pandas
* Scikit-Learn
* XGBoost

### Trading APIs

* CCXT
* OANDA API

### Async Networking

* aiohttp
* websockets

### GUI

* PySide6
* PyQtGraph

### Database

* SQLAlchemy

---

# Roadmap

Future improvements include:

* distributed strategy execution
* GPU machine learning inference
* high-frequency trading support
* portfolio optimization
* reinforcement learning strategies

---

# License

MIT License

---

# Author

Sopotek Technologies

---

<p align="center">
Python 3.11 • MIT License • Event-Driven Architecture
</p>
```


